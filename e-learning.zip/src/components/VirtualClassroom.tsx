import { useRef, useState } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, PerspectiveCamera, Text, Box, Plane } from '@react-three/drei'
import * as THREE from 'three'
import { Button } from './ui/button'
import { Card } from './ui/card'
import { Video, Mic, MicOff, VideoOff, Users, MessageSquare, Hand, Monitor } from 'lucide-react'

function Desk({ position, color = '#8B4513' }: { position: [number, number, number], color?: string }) {
  return (
    <group position={position}>
      {/* Desk Top */}
      <Box args={[1.2, 0.05, 0.8]} position={[0, 0.4, 0]}>
        <meshStandardMaterial color={color} />
      </Box>
      {/* Legs */}
      <Box args={[0.05, 0.4, 0.05]} position={[-0.5, 0.2, -0.3]}>
        <meshStandardMaterial color={color} />
      </Box>
      <Box args={[0.05, 0.4, 0.05]} position={[0.5, 0.2, -0.3]}>
        <meshStandardMaterial color={color} />
      </Box>
      <Box args={[0.05, 0.4, 0.05]} position={[-0.5, 0.2, 0.3]}>
        <meshStandardMaterial color={color} />
      </Box>
      <Box args={[0.05, 0.4, 0.05]} position={[0.5, 0.2, 0.3]}>
        <meshStandardMaterial color={color} />
      </Box>
    </group>
  )
}

function Chair({ position }: { position: [number, number, number] }) {
  return (
    <group position={position}>
      {/* Seat */}
      <Box args={[0.5, 0.05, 0.5]} position={[0, 0.3, 0]}>
        <meshStandardMaterial color="#4A4A4A" />
      </Box>
      {/* Backrest */}
      <Box args={[0.5, 0.4, 0.05]} position={[0, 0.5, -0.2]}>
        <meshStandardMaterial color="#4A4A4A" />
      </Box>
      {/* Legs */}
      {[-0.2, 0.2].map((x) =>
        [-0.2, 0.2].map((z) => (
          <Box key={`${x}-${z}`} args={[0.05, 0.3, 0.05]} position={[x, 0.15, z]}>
            <meshStandardMaterial color="#333333" />
          </Box>
        ))
      )}
    </group>
  )
}

function Whiteboard() {
  return (
    <group position={[0, 2, -4.9]}>
      {/* Board */}
      <Plane args={[4, 2]}>
        <meshStandardMaterial color="#FFFFFF" />
      </Plane>
      {/* Frame */}
      <Box args={[4.1, 0.1, 0.05]} position={[0, 1.05, -0.05]}>
        <meshStandardMaterial color="#666666" />
      </Box>
      <Box args={[4.1, 0.1, 0.05]} position={[0, -1.05, -0.05]}>
        <meshStandardMaterial color="#666666" />
      </Box>
      <Box args={[0.1, 2.1, 0.05]} position={[-2.05, 0, -0.05]}>
        <meshStandardMaterial color="#666666" />
      </Box>
      <Box args={[0.1, 2.1, 0.05]} position={[2.05, 0, -0.05]}>
        <meshStandardMaterial color="#666666" />
      </Box>

      {/* Text on Whiteboard */}
      <Text
        position={[0, 0.5, 0.01]}
        fontSize={0.3}
        color="#2563EB"
        anchorX="center"
        anchorY="middle"
      >
        Welcome to EduVerse
      </Text>
      <Text
        position={[0, 0, 0.01]}
        fontSize={0.15}
        color="#1F2937"
        anchorX="center"
        anchorY="middle"
      >
        Virtual Classroom
      </Text>
      <Text
        position={[0, -0.4, 0.01]}
        fontSize={0.12}
        color="#6B7280"
        anchorX="center"
        anchorY="middle"
      >
        Interactive Learning Experience
      </Text>
    </group>
  )
}

function ClassroomScene() {
  const groupRef = useRef<THREE.Group>(null)

  useFrame(({ clock }) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = Math.sin(clock.getElapsedTime() * 0.2) * 0.1
    }
  })

  return (
    <group ref={groupRef}>
      {/* Floor */}
      <Plane args={[12, 10]} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
        <meshStandardMaterial color="#D4A574" />
      </Plane>

      {/* Walls */}
      <Plane args={[12, 5]} position={[0, 2.5, -5]} receiveShadow>
        <meshStandardMaterial color="#E8E8E8" />
      </Plane>
      <Plane args={[10, 5]} rotation={[0, Math.PI / 2, 0]} position={[-6, 2.5, 0]} receiveShadow>
        <meshStandardMaterial color="#F0F0F0" />
      </Plane>
      <Plane args={[10, 5]} rotation={[0, -Math.PI / 2, 0]} position={[6, 2.5, 0]} receiveShadow>
        <meshStandardMaterial color="#F0F0F0" />
      </Plane>

      {/* Ceiling */}
      <Plane args={[12, 10]} rotation={[Math.PI / 2, 0, 0]} position={[0, 5, 0]}>
        <meshStandardMaterial color="#FFFFFF" />
      </Plane>

      {/* Whiteboard at front */}
      <Whiteboard />

      {/* Student Desks - 3 rows, 4 desks each */}
      {[-3, -1, 1, 3].map((x, i) =>
        [1, 2.5, 4].map((z, j) => (
          <group key={`${i}-${j}`}>
            <Desk position={[x, 0, z]} />
            <Chair position={[x, 0, z + 0.6]} />
          </group>
        ))
      )}

      {/* Teacher's Desk */}
      <Desk position={[0, 0, -3.5]} color="#654321" />
      <Chair position={[0, 0, -2.8]} />

      {/* Lights */}
      <ambientLight intensity={0.5} />
      <pointLight position={[0, 4, 0]} intensity={0.8} />
      <pointLight position={[-4, 3, -2]} intensity={0.5} />
      <pointLight position={[4, 3, -2]} intensity={0.5} />
      <directionalLight position={[5, 5, 5]} intensity={0.5} castShadow />
    </group>
  )
}

export function VirtualClassroom() {
  const [isMuted, setIsMuted] = useState(true)
  const [isVideoOff, setIsVideoOff] = useState(false)
  const [handRaised, setHandRaised] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <h1 className="text-4xl font-bold mb-2">3D Virtual Classroom</h1>
          <p className="text-muted-foreground">
            Experience immersive learning in our interactive 3D environment
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* 3D Canvas */}
          <div className="lg:col-span-3">
            <Card className="overflow-hidden">
              <div className="aspect-video bg-gray-900 relative">
                <Canvas shadows style={{ width: '100%', height: '100%' }}>
                  <PerspectiveCamera makeDefault position={[0, 3, 8]} />
                  <OrbitControls
                    enablePan={true}
                    enableZoom={true}
                    enableRotate={true}
                    maxPolarAngle={Math.PI / 2}
                    minDistance={5}
                    maxDistance={15}
                  />
                  <ClassroomScene />
                  <color attach="background" args={['#1a1a1a']} />
                </Canvas>

                {/* Controls Overlay */}
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-3 bg-background/90 backdrop-blur-sm px-6 py-3 rounded-full border">
                  <Button
                    size="icon"
                    variant={isMuted ? "destructive" : "default"}
                    onClick={() => setIsMuted(!isMuted)}
                    className="rounded-full"
                  >
                    {isMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
                  </Button>
                  <Button
                    size="icon"
                    variant={isVideoOff ? "destructive" : "default"}
                    onClick={() => setIsVideoOff(!isVideoOff)}
                    className="rounded-full"
                  >
                    {isVideoOff ? <VideoOff className="h-5 w-5" /> : <Video className="h-5 w-5" />}
                  </Button>
                  <Button
                    size="icon"
                    variant={handRaised ? "default" : "outline"}
                    onClick={() => setHandRaised(!handRaised)}
                    className="rounded-full"
                  >
                    <Hand className="h-5 w-5" />
                  </Button>
                  <Button
                    size="icon"
                    variant="outline"
                    className="rounded-full"
                  >
                    <Monitor className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            </Card>

            {/* Instructions */}
            <Card className="mt-4 p-4">
              <h3 className="font-semibold mb-2">Navigation Controls</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Click and drag to rotate the view</li>
                <li>• Scroll to zoom in/out</li>
                <li>• Right-click and drag to pan</li>
                <li>• Use the bottom controls for mic, camera, and interactions</li>
              </ul>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Participants */}
            <Card className="p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Participants (24)
                </h3>
              </div>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {['Dr. Sarah Johnson (Instructor)', 'John Doe', 'Alice Smith', 'Bob Wilson', 'Emma Davis'].map((name, i) => (
                  <div key={i} className="flex items-center gap-2 p-2 rounded hover:bg-accent">
                    <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-sm">
                      {name[0]}
                    </div>
                    <span className="text-sm">{name}</span>
                    {i === 0 && <span className="text-xs bg-primary/20 px-2 py-0.5 rounded">Host</span>}
                  </div>
                ))}
              </div>
            </Card>

            {/* Chat */}
            <Card className="p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  Chat
                </h3>
              </div>
              <div className="space-y-3 max-h-60 overflow-y-auto mb-3">
                <div className="text-sm">
                  <p className="font-medium text-xs text-muted-foreground mb-1">Dr. Sarah Johnson</p>
                  <p className="bg-accent p-2 rounded">Welcome everyone to today's session!</p>
                </div>
                <div className="text-sm">
                  <p className="font-medium text-xs text-muted-foreground mb-1">John Doe</p>
                  <p className="bg-accent p-2 rounded">Thank you! Excited to learn.</p>
                </div>
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Type a message..."
                  className="flex-1 px-3 py-2 text-sm border rounded-md bg-background"
                />
                <Button size="sm">Send</Button>
              </div>
            </Card>

            {/* Session Info */}
            <Card className="p-4">
              <h3 className="font-semibold mb-3">Session Info</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Status:</span>
                  <span className="font-medium text-green-600">Live</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Duration:</span>
                  <span className="font-medium">45 min</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Course:</span>
                  <span className="font-medium">Web Dev 101</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
